import java.util.*;
import java.util.stream.Collectors;

public class KruskalAlgorithm {

    public static List<Edge> kruskal(int numberOfVertices, List<Edge> edges) {
        int[] parents = new int[numberOfVertices];
        for (int i = 0; i < numberOfVertices; i++) {
            parents[i] = i;
        }
        Queue<Edge> queue = new PriorityQueue<>();
        queue.addAll(edges);
        List<Edge> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            Edge current = queue.poll();
            int start = current.getStartNode();
            int end = current.getEndNode();
            if(findRoot(start,parents)!=findRoot(end,parents)){
                if (parents[end] != end) {
                    reverseParents(end, parents[end], parents);
                }
                parents[end]=start;
                result.add(current);
            }
        }

        Collections.sort(result,compareEdge);
        

        return result;
    }

    public static int findRoot(int node, int[] parents) {

        int current = node;
         while (parents[current]!=current) {
             current = parents[current];
         }

         return current;
    }  public static void reverseParents (int a, int b, int[] parents) {

        if (parents[b] == b) {
            parents[b] = a;
            return;
        }
        reverseParents(b, parents[b],parents);
        parents[b] = a;

    }

    private static Comparator<Edge> compareEdge = (e1,e2) -> {
        if(e1.compareTo(e2) != 0) {
            return e1.compareTo(e2);

        } else {
            return Integer.compare(e1.getStartNode(),e2.getStartNode());
        }
    };
}
