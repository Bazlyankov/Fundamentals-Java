import java.util.List;

public class StronglyConnectedComponents {

    public static List<List<Integer>> findStronglyConnectedComponents(List<Integer>[] targetGraph) {
        return null;
    }
}
