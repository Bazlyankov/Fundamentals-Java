public class EdmondsKarp {
    public static int findMaxFlow(int[][] targetGraph) {
        return -1;
    }
}
